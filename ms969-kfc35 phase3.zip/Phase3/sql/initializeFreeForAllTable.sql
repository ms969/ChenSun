INSERT INTO freeforall.posts
VALUES (null, "Kevin", NOW(), "JXV+k4PPCgU=79GJyI5/CkoEhY/A8XV+dS4Qkc7vLhBaIQIibZMmi7wm9TG9AkZCXCAFEOcpl+TNk9KqnSw3vqUi
OdB8wgHFqfEUgNjC+bjDlwoC5NIdN34=", NOW()),
(null, "MJ", NOW(), "rYkFLcz4Z8E=nCu3FnDk8YIvH53UF8VzBk1nLk6vD2uZdQpIwzdXAn1tmx6h/3eF8D5FycK/M1RWMdjui7F8JVP+
PVIjrH9qqg==", NOW()),
(null, "MJ", NOW(), "+iDZIUm3onI=8oVFVM0MNeoU8w+6oLISanmGO/c+nh8VWhc/ji1T12jr4HnH85zDdfbvn0LLbFn0aBSGHFpF4t++
vQmpMh5QJYi79WSmvcoa", NOW());
INSERT INTO freeforall.postprivileges
VALUES (1, "MJ", 'viewpost'), (2, "Kevin", 'view'), (3, "Kevin", 'viewpost');
INSERT INTO freeforall.replies
VALUES (1, null, "MJ", NOW(), "bO1CpTSnofY=UUYkipNIiEUJc5WHQLCLRw=="),
(3, null, "Kevin", NOW(), "YJ157FYsgrI=MeHTF385DENow8/EjrlVw3Fd9KieMpA+TQ5m0OMJ46ingLlJpx34Q5DpcXNSOJYygq1seSWm+Cds
hfeyXn16qYegr2I2qNi+DSBTh0FzxaQ=")